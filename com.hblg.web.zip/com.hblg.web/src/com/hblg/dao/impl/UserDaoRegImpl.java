package com.hblg.dao.impl;

import com.hblg.bean.User;
import com.hblg.dao.UserDao;

public class UserDaoRegImpl extends AbstractUserDao {

    @Override
    public boolean register(User user) {
        //新业务 逻辑的实现

        return false;
    }
}
