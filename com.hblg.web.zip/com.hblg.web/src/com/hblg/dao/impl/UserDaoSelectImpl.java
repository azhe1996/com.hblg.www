package com.hblg.dao.impl;

import com.hblg.bean.User;

import java.util.List;

public class UserDaoSelectImpl extends AbstractUserDao {

    @Override
    public int count() {
        //实现 具体 的实现 内容
        return super.count();
    }

    @Override
    public List<User> getAll() {
        return super.getAll();
    }
}
